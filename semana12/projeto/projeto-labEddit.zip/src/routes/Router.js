import React from "react";
import { Route, Switch } from "react-router-dom";
import LoginPage from "../screens/LoginPage/LoginPage";
import SignUpPage from "../screens/SignUpPage/SignUpPage";
import FeedPage from "../screens/FeedPage/FeedPage";
import PostsPage from "../screens/PostPage/PostPage";
import ErrorPage from "../screens/ErrorPage/ErrorPage";
import AddPostPage from "../screens/AddPostPage/AddPostPage";

const Router = (props) => {
  return (
    <Switch>
      <Route exact path={"/login"}>
        <LoginPage setButtonName={props.setButtonName} />
      </Route>
      <Route exact path={"/cadastro"}>
        <SignUpPage setButtonName={props.setButtonName} />
      </Route>
      <Route exact path={["/feed", "/"]}>
        <FeedPage />
      </Route>
      <Route exact path={"/posts"}>
        <PostsPage />
      </Route>
      <Route exact path={"/adicionarPost"}>
        <AddPostPage />
      </Route>
      <Route>
        <ErrorPage />
      </Route>
    </Switch>
  );
};

export default Router;
