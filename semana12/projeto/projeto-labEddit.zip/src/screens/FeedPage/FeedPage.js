import React from "react";
import useProtectedPage from "../../hooks/useProtectedPage";
import PostCard from "./PostCard";
import useRequestData from "../../hooks/useRequestData";
import Loading from "../../components/Loading/Loading";
import { AddPostButton, FeedContainer } from "./styled";
import { goToAddRecipe, goToPostPage } from "../../routes/Coordinator";
import { useHistory } from "react-router-dom";
import { Add } from "@material-ui/icons";

const FeedPage = () => {
  useProtectedPage();
  const history = useHistory();
  const recipes = useRequestData([], "/recipe/feed");

  const renderFeed = () =>
    recipes.map((item) => {
      return (
        <PostCard
          key={item.recipe_id}
          onClick={() => goToPostPage(history, item.recipe_id)}
          title={item.title}
          image={item.image}
        />
      );
    });

  return (
    <>
      <FeedContainer>
        {recipes.length > 0 ? renderFeed() : <Loading />}
      </FeedContainer>
      <AddPostButton color={"primary"} onClick={() => goToAddPost(history)}>
        <Add />
      </AddPostButton>
    </>
  );
};

export default FeedPage;
