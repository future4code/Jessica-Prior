import React from "react";
import LabEdditLogo from "../../assets/logoCentro.png";
import { ScreenContainer } from "./styled";
import SignUpForm from "./SignUpForm";
import useUnprotectedPage from "../../hooks/useUnprotecdetPage";
import { LogoImage } from "./styled";

const SignUpPage = (props) => {
  useUnprotectedPage();

  return (
    <ScreenContainer>
      <LogoImage alt={"logo"} src={LabEdditLogo} />
      <SignUpForm setButtonName={props.setButtonName} />
    </ScreenContainer>
  );
};

export default SignUpPage;
