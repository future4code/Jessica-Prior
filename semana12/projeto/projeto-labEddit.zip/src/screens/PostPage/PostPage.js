import React from "react";
import useProtectedPage from "../../hooks/useProtectedPage";
import { useParams } from "react-router-dom";
import useRequestData from "../../hooks/useRequestData";
import Typography from "@material-ui/core/Typography";
import Loading from "../../components/Loading/Loading";
import { PostContainer, ScreenContainer } from "./styled";

const RecipeDetailPage = () => {
  useProtectedPage();
  const { id } = useParams();
  const post = useRequestData([], `/posts/${id}`);

  const renderDetail = () => (
    <ScreenContainer>
      <PostContainer>
        <Typography
          gutterBottom
          align={"center"}
          variant={"h5"}
          color={"primary"}
        >
          {post.title}
        </Typography>
        <Typography align={"center"}>{post.text}</Typography>
      </PostContainer>
    </ScreenContainer>
  );

  return <> {post ? renderDetail() : <Loading />}</>;
};

export default RecipeDetailPage;
