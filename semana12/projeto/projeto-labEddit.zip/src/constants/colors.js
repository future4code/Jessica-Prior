export const primaryColor = "#000000";
export const neutralColor = "#1C1C1C";
