import React from "react";

function Logo() {
  return (
    <div>
      <img src="./images/icons/logo.png" alt="Astromatch Logo" />
    </div>
  );
}

export default Logo;
