export const baseUrl =
  "https://us-central1-labenu-apis.cloudfunctions.net/labefy/playlists";

export const axiosConfig = {
  headers: {
    Authorization: "jessica-prior-jackson"
  }
};
