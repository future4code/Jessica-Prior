import React from "react";
import { useHistory } from "react-router-dom";
import { goToHomePage, goBack, goToCreateTripPage } from "../router/goToPages";

const LoginPage = () => {
  const history = useHistory();

  return (
    <div>
      <p>Pagina de login</p>
      <button onClick={() => goToCreateTripPage(history)}>Logar</button>
      <button onClick={() => goToHomePage(history)}>Ir para Home</button>
      <button onClick={() => goBack(history)}>Voltar</button>
    </div>
  );
};

export default LoginPage;
