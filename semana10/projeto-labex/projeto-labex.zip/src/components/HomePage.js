import React from "react";
import { useHistory } from "react-router-dom";
import {
  goToLoginPage,
  goToApplicationFormPage,
  goToListTripsPage
} from "../router/goToPages";

const HomePage = () => {
  const history = useHistory();

  return (
    <div>
      <p>Pagina Inicial</p>
      <button onClick={() => goToLoginPage(history)}>Login</button>
      <button onClick={() => goToApplicationFormPage(history)}>
        Inscrição
      </button>
      <button onClick={() => goToListTripsPage(history)}>
        Lista de viagens
      </button>
    </div>
  );
};

export default HomePage;