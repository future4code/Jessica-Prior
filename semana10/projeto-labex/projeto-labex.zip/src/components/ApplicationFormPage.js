import React from "react";
import { useHistory } from "react-router-dom";
import { goToHomePage, goBack } from "../router/goToPages";

const ApplicationFormPage = () => {
  const history = useHistory();

  return (
    <div>
      <p>Pagina de inscrição para viajar</p>
      <button onClick={() => goToHomePage(history)}>Ir para Home</button>
      <button onClick={() => goBack(history)}>Voltar</button>

      <div>
        <p>Formulário de inscrição</p>

        <label>Nome:</label>
        <input></input>
        <label>Idade:</label>
        <input></input>
        <label>Profissão:</label>
        <input></input>
        <label>País:</label>
        <input></input>
        <label>
          Escreva brevemente porque deveria ser escolhido para viagem:
        </label>
        <input></input>
        <button>Enviar</button>
      </div>
    </div>
  );
};

export default ApplicationFormPage;
