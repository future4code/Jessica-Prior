import React from "react";
import { useHistory } from "react-router-dom";
import { goToHomePage, goBack } from "../router/goToPages";

const CreateTripPage = () => {
  const history = useHistory();

  return (
    <div>
      <p>Pagina de criação de viagens</p>
      <button onClick={() => goToHomePage(history)}>Ir para Home</button>
      <button onClick={() => goBack(history)}>Voltar</button>
    </div>
  );
};

export default CreateTripPage;
