import React, { useEffect } from "react";
import { useHistory } from "react-router-dom";
import { goToHomePage } from "../router/goToPages";
import { useProtectPage } from "../hook/useProtectPage";
import axios from "axios";

const baseUrl =
  "https://us-central1-labenu-apis.cloudfunctions.net/labeX/jessica-jackson/trips";

const CreateTripPage = () => {
  const history = useHistory();

  useEffect(() => {
    const token = localStorage.getItem("token");

    if (token) {
      getCreateTripPage();
    } else {
      history.push("/login");
    }
  }, [history]);

  const getCreateTripPage = () => {
    axios
      .get(`${baseUrl}/trips/`, {
        headers: {
          auth: localStorage.getItem("token")
        }
      })
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.log(error.message);
      });
  };

  useProtectPage(getCreateTripPage);

  return (
    <div>
      <p>Criação de viagens</p>
      <button onClick={() => goToHomePage(history)}>Ir para Home</button>

      <div>
        <p>Formulário para criar uma nova viagem</p>
        <label>Nome:</label>
        <input></input>
        <label>Planeta:</label>
        <input></input>
        <label>Data:</label>
        <input></input>
        <label>Duração em dias:</label>
        <input></input>
        <label>Descrição:</label>
        <input></input>
        <button>Criar viagem</button>
      </div>
    </div>
  );
};

export default CreateTripPage;
